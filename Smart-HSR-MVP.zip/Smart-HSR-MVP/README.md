# Smart HSR — MVP (2025)

هذا هو إصدار **MVP فعّال بالكامل** من لوحة القيادة التنفيذية Smart HSR بنفس التصميم.
تمت تهيئته للنشر على **GitHub Pages** أو **Firebase Hosting**.

## المتطلبات
- حساب Firebase مع Firestore مفعّل.
- (اختياري) مفتاح Gemini Vision API لتحليل الصور مباشرة من الواجهة.

## الإعداد السريع
1) ارفع المجلد كاملًا إلى مستودع GitHub باسم `Smart-HSR-MVP` وفعل GitHub Pages.
2) أو استخدم `firebase init hosting` ثم `firebase deploy`.

## تخصيص
- مفاتيح Firebase موجودة داخل `firebase.js`.
- مفتاح Gemini داخل `ai.js`.

## ملاحظات
- لحماية مفاتيحك في الإنتاج، يُفضّل تمرير طلبات Gemini عبر خادم وسيط (Cloud Functions).

— تم الإنشاء: 2025-10-22
