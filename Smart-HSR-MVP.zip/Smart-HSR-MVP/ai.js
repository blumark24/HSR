// ai.js
// ✅ تحليل الصور عبر Gemini Vision (Flash) — للبيئات التجريبية مباشرة من الواجهة.
// ⚠️ مستحسن لاحقًا نقل المفتاح إلى خادم وسيط لحمايته في الإنتاج.

const GEMINI_API_KEY = "AIzaSyCstRnAY_9TO9f4l49TTHEjVaoqjtZriJk";

export async function analyzeImageByVision(imageUrl) {
  const base64 = await toBase64FromUrl(imageUrl);
  const prompt = `
قم بتحليل الصورة التالية في سياق ملاحظات بلدية مكة، وارجع الرد بصيغة JSON مثل:
{
  "title": "عنوان الملاحظة",
  "description": "تحليل فني قصير وواضح يتضمن السبب والإجراء المقترح ودرجة الخطورة (منخفضة/متوسطة/مرتفعة)"
}`.trim();

  const res = await fetch(
    `https://generativelanguage.googleapis.com/v1/models/gemini-1.5-flash:generateContent?key=${GEMINI_API_KEY}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }, { inline_data: { mime_type: "image/jpeg", data: base64 } }] }]
      })
    }
  );

  const data = await res.json();
  const text = data?.candidates?.[0]?.content?.parts?.[0]?.text?.trim() || "{}";
  try {
    const parsed = JSON.parse(text);
    if (!parsed.description) parsed.description = text;
    if (!parsed.title) parsed.title = "ملاحظة ميدانية";
    return parsed;
  } catch {
    return { title: "ملاحظة ميدانية", description: text };
  }
}

export async function toBase64FromUrl(url) {
  const response = await fetch(url);
  const blob = await response.blob();
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve(reader.result.split(",")[1]);
    reader.readAsDataURL(blob);
  });
}
