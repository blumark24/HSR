// firebase.js
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import { getFirestore, collection, getDocs, addDoc, updateDoc, doc, serverTimestamp, query, orderBy } 
  from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";

// ✅ إعدادات مشروعك (حسب تأكيدك)
const firebaseConfig = {
  apiKey: "AIzaSyBfClVxFIXgUXL4olEv5SepUDtzk0dq3lo",
  authDomain: "gen-lang-client-0349944917.firebaseapp.com",
  projectId: "gen-lang-client-0349944917",
  storageBucket: "gen-lang-client-0349944917.firebasestorage.app",
  messagingSenderId: "883065484771",
  appId: "1:883065484771:web:c907bb5a51f68caad75cd6"
};

export let db = null;
export let FIREBASE_READY = false;

try {
  const app = initializeApp(firebaseConfig);
  db = getFirestore(app);
  FIREBASE_READY = !!db;
  console.log('✅ Firebase متصل بنجاح');
  const ui = document.getElementById('userInfo');
  if (ui) ui.textContent = '✅ تم الاتصال بـ Firebase بنجاح.';
} catch (e) {
  console.warn('⚠️ فشل الاتصال بـ Firebase:', e);
  const ui = document.getElementById('userInfo');
  if (ui) ui.textContent = '⚠️ تشغيل محلي بدون Firebase.';
}

// ========== عمليات Firestore ==========
export async function loadObservations() {
  if (!FIREBASE_READY) return [];
  const q = query(collection(db, 'observations'), orderBy('createdAt', 'desc'));
  const snapshot = await getDocs(q);
  const arr = [];
  snapshot.forEach(d => arr.push({ ...d.data(), docId: d.id }));
  return arr;
}

export async function addObservation(payload) {
  if (!FIREBASE_READY) return null;
  const ref = await addDoc(collection(db, 'observations'), { ...payload, createdAt: serverTimestamp() });
  return ref.id;
}

export async function updateObservation(docId, fields) {
  if (!FIREBASE_READY) return;
  await updateDoc(doc(db, 'observations', docId), fields);
}
