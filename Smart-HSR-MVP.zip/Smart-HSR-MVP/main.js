// main.js
import { FIREBASE_READY, loadObservations, addObservation, updateObservation } from "./firebase.js";
import { analyzeImageByVision } from "./ai.js";

// حالة عامة
window.observations = [];
window.currentObservation = null;
window.currentFile = null;

// تشغيل عند تحميل الصفحة
document.addEventListener("DOMContentLoaded", async () => {
  try {
    if (FIREBASE_READY) {
      window.observations = await loadObservations();
      renderObservations(window.observations);
    }
  } catch (e) {
    console.error(e);
  }
  lucide.createIcons();
});

// ========== عرض القائمة ==========
function renderObservations(data) {
  const list = document.getElementById("observationsList");
  if (!list) return;
  list.innerHTML = "";
  if (!data.length) {
    list.innerHTML = `<div class="text-center text-gray-500 mt-6">لا توجد ملاحظات بعد.</div>`;
    return;
  }
  data.forEach(o => {
    const div = document.createElement("div");
    div.className = "observation-item p-3 rounded-lg bg-gray-50 border cursor-pointer";
    div.innerHTML = `
      <p class="font-bold" style="color:var(--color-navy)">${o.title || "—"}</p>
      <p class="text-sm text-gray-600">${o.date || ""}</p>
      <p class="text-xs text-gray-500">${o.status || ""}</p>`;
    div.onclick = () => showDetails(o);
    list.appendChild(div);
  });
}

// ========== التفاصيل ==========
window.showDetails = function(obs) {
  window.currentObservation = obs;
  const stColor = {
    "جديد": "bg-red-600",
    "قيد التنفيذ": "bg-yellow-500",
    "تمت المعالجة": "bg-green-600"
  }[obs.status] || "bg-gray-400";

  document.getElementById("detailTitle").textContent = obs.title || "—";
  document.getElementById("detailType").textContent = obs.type || "—";
  document.getElementById("detailLocation").textContent = obs.location || "—";
  document.getElementById("detailDate").textContent = obs.date || "—";
  document.getElementById("detailID").textContent = obs.docId || "—";

  const statusEl = document.getElementById("detailStatus");
  statusEl.className = `inline-block px-3 py-1 text-sm font-semibold rounded-full text-white ${stColor}`;
  statusEl.textContent = obs.status || "—";

  document.getElementById("detailDescription").textContent = obs.aiAnalysis || "لم يتم التحليل بعد.";
  document.getElementById("detailPlaceholder").classList.add("hidden");
  document.getElementById("observationDetail").classList.remove("hidden");
  lucide.createIcons();
};

// ========== التحليل بالذكاء الاصطناعي ==========
window.analyzeImage = async function() {
  const obs = window.currentObservation;
  if (!obs || !obs.imagePath) return alert("❌ لا توجد صورة للتحليل.");

  const container = document.getElementById("aiResultContainer");
  const title = document.getElementById("aiResultTitle");
  const content = document.getElementById("aiResultContent");

  title.textContent = "⏳ جاري التحليل...";
  content.innerHTML = `<div class="loading-spinner" style="margin:0 auto"></div>`;
  container.classList.remove("hidden");

  try {
    const result = await analyzeImageByVision(obs.imagePath);
    const analysis = result.description || "لم يتم التحليل.";
    title.textContent = "✅ نتيجة التحليل:";
    content.innerHTML = `<div class='communication-draft'>${analysis}</div>`;

    if (FIREBASE_READY && obs.docId) {
      await updateObservation(obs.docId, { aiAnalysis: analysis, lastAnalyzedAt: new Date().toISOString() });
    }
  } catch (e) {
    console.error(e);
    title.textContent = "❌ فشل التحليل";
    content.innerHTML = `<p>حدث خطأ أثناء تحليل الصورة. يرجى المحاولة لاحقاً.</p>`;
  }
};

// ========== KPI (مبسطة) ==========
window.generateKpiInsights = function() {
  const kpiDiv = document.getElementById('kpi-insight-result');
  if (!kpiDiv) return;
  const total = window.observations.length;
  const closed = window.observations.filter(o => o.status === "تمت المعالجة").length;
  kpiDiv.innerHTML = `
    <div class="p-4 bg-white rounded-xl shadow">
      <p class="text-lg font-bold" style="color:#0f766e">ملخص تنفيذي:</p>
      <p class="text-gray-700">إجمالي الملاحظات: <b>${total}</b> — المغلقة: <b>${closed}</b>.</p>
      <p class="text-gray-700">نوصي بتسريع توثيق الصور الختامية لتحسين الأداء.</p>
    </div>`;
};

// ========== واجهة المودال والإدخال ==========
window.openModal = function(id) {
  const modal = document.getElementById(id);
  if (modal) modal.style.display = "flex";
};
window.closeModal = function(id) {
  const modal = document.getElementById(id);
  if (modal) modal.style.display = "none";
};

window.smartLogout = function() {
  const btn = document.getElementById('logout-btn');
  if (!btn) return;
  btn.disabled = true;
  btn.innerHTML = '<div class="loading-spinner" style="border-top:4px solid var(--color-teal);"></div> جاري تسجيل الخروج...';
  btn.classList.add('flex','justify-center','items-center');
  setTimeout(() => { alert('تم تسجيل الخروج بنجاح ✅'); window.location.href = "login.html"; }, 800);
};

window.handleFileUpload = function(event) {
  const file = event.target.files?.[0];
  if (!file) return;
  window.currentFile = file;
  const fs = document.getElementById('fileStatus');
  if (fs) fs.textContent = `📸 تم اختيار: ${file.name}`;
  checkSmartInputState();
};

window.checkSmartInputState = function() {
  const text = (document.getElementById('rawObservationInput')?.value || '').trim();
  const btn = document.getElementById('processSmartInputBtn');
  if (btn) btn.disabled = !text && !window.currentFile;
};

window.getLocation = function() {
  const status = document.getElementById('locationStatus');
  if (!navigator.geolocation) {
    status.textContent = "المتصفح لا يدعم تحديد الموقع"; return;
  }
  status.textContent = "جارٍ تحديد الموقع...";
  navigator.geolocation.getCurrentPosition(
    (pos) => {
      document.getElementById('inputLatitude').value = pos.coords.latitude;
      document.getElementById('inputLongitude').value = pos.coords.longitude;
      status.textContent = `تم تحديد الموقع (${pos.coords.latitude.toFixed(5)}, ${pos.coords.longitude.toFixed(5)})`;
    },
    (err) => { status.textContent = "❌ فشل تحديد الموقع"; console.error(err); }
  );
};

function fileToDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = e => resolve(e.target.result);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

window.processSmartInput = async function() {
  const rawText = (document.getElementById('rawObservationInput')?.value || '').trim();
  const lat = document.getElementById('inputLatitude')?.value || "غير محدد";
  const lon = document.getElementById('inputLongitude')?.value || "غير محدد";

  document.getElementById('modalStep1').style.display = 'none';
  document.getElementById('modalResult').style.display = 'block';
  const resultDiv = document.getElementById('modalResultContent');
  resultDiv.innerHTML = '<p>🔍 جاري التحليل بالذكاء الصناعي...</p>';

  try {
    let uploadedUrl = null;
    if (window.currentFile) {
      uploadedUrl = await fileToDataUrl(window.currentFile); // Data URL لحفظها مباشرة
    }

    // عنوان وتحليل مبسط — يمكن استدعاء Gemini لاحقًا إن رغبت
    const aiTitle = rawText || "ملاحظة ميدانية جديدة";
    const aiDescription = "";

    const newDate = new Date().toISOString().slice(0, 10);
    const payload = {
      title: aiTitle,
      date: newDate,
      type: "صيانة",
      status: "جديد",
      location: `(${lat}, ${lon})`,
      imagePath: uploadedUrl,
      aiAnalysis: aiDescription
    };

    let docId = "local-" + Math.random().toString(36).slice(2);
    if (FIREBASE_READY) {
      const ref = await addObservation(payload);
      if (ref) docId = ref;
    }
    const obj = { docId, ...payload };
    window.observations.unshift(obj);
    renderObservations(window.observations);

    resultDiv.innerHTML = `✅ تمت إضافة الملاحظة "<b>${aiTitle}</b>" وتحليلها بنجاح.`;
  } catch (err) {
    console.error(err);
    resultDiv.textContent = "❌ فشل في معالجة الملاحظة.";
  }
};

// تقارير PDF (تجريبية)
window.generatePdfReport = function(){
  alert("ميزة توليد PDF سيتم تفعيلها في الإصدار القادم ✅");
};

// تصفية القائمة
window.handleFilterChange = function() {
  const filter = document.getElementById("observationFilter").value;
  const filtered = (filter === "الكل")
    ? window.observations
    : window.observations.filter(o => o.type === filter || o.status === filter);
  renderObservations(filtered);
};
